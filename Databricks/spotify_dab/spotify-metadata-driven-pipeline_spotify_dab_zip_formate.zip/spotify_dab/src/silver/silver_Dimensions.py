# Databricks notebook source
# DBTITLE 1,Cell 1
from pyspark.sql.functions import *
from pyspark.sql.types import *

import os 
import sys 
print(os.getcwd())

project_path = os.path.join(os.getcwd(),'..','..')
sys.path.append(project_path)

from utils.transformations import reusable

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimUser**

# COMMAND ----------

# MAGIC %md 
# MAGIC ### **AUTOLOADER**

# COMMAND ----------

df_user = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimUser/checkpoint")\
    .load("abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimUser")


# COMMAND ----------

df_user = df_user.withColumn("user_name", upper(col("user_name")))

# COMMAND ----------

# DBTITLE 1,Cell 7
df_user_obj = reusable()
df_user = df_user_obj.dropColumns(df_user , ['_rescued_data'])
df_user = df_user.dropDuplicates(['user_id'])

# COMMAND ----------

df_user.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimUser/checkpoint")\
    .trigger(once=True)\
    .option("path","abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimUser/data")\
    .toTable("spotify_cata.silver.DimUser")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT * FROM spotify_cata.silver.DimUser

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimArtist**

# COMMAND ----------

df_artist = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimArtist/checkpoint")\
    .load("abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimArtist")


# COMMAND ----------

df_artist_obj = reusable()
df_artist = df_artist_obj.dropColumns(df_artist , ['_rescued_data'])
df_artist = df_artist.dropDuplicates(['artist_id'])

# COMMAND ----------

df_artist.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimArtist/checkpoint")\
    .trigger(once=True)\
    .option("path","abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimArtist/data")\
    .toTable("spotify_cata.silver.DimArtist")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT * FROM spotify_cata.silver.DimArtist

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimTrack**

# COMMAND ----------

df_track = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimTrack/checkpoint")\
    .load("abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimTrack")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM parquet.`abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimTrack`

# COMMAND ----------

df_track = df_track.withColumn("durationFlag",when(col("duration_sec")<150,"low")
                               .when(col("duration_sec")<300,"medium")
                               .otherwise("high"))


df_track = df_track.withColumn("track_name",regexp_replace(col("track_name"),"-"," "))


# COMMAND ----------

df_track_obj = reusable()
df_track = df_track_obj.dropColumns(df_track , ['_rescued_data'])
# df_track = df_track.dropDuplicates(['track_id'])

# COMMAND ----------

df_track.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimTrack/checkpoint")\
    .trigger(once=True)\
    .option("path","abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimTrack/data")\
    .toTable("spotify_cata.silver.DimTrack")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT   * FROM spotify_cata.silver.DimTrack

# COMMAND ----------

# MAGIC %md
# MAGIC ## **DimDate**

# COMMAND ----------

df_date = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimDate/checkpoint")\
    .load("abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimDate")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM parquet.`abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/DimDate`

# COMMAND ----------

df_date_obj = reusable()
df_date = df_date_obj.dropColumns(df_date , ['_rescued_data'])
df_date = df_date.dropDuplicates(['date_key'])

# COMMAND ----------

df_date.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimDate/checkpoint")\
    .trigger(once=True)\
    .option("path","abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/DimDate/data")\
    .toTable("spotify_cata.silver.DimDate")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT * FROM spotify_cata.silver.DimDate

# COMMAND ----------

# MAGIC %md
# MAGIC ## **FactStream**

# COMMAND ----------

df_fact = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "parquet")\
    .option("cloudFiles.schemaLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/FactStream/checkpoint")\
    .load("abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/FactStream")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM parquet.`abfss://bronze@spotifyprojectdlyash.dfs.core.windows.net/FactStream`

# COMMAND ----------

df_fact_obj = reusable()
df_fact = df_fact_obj.dropColumns(df_fact , ['_rescued_data'])
df_fact = df_fact.dropDuplicates(['stream_id'])

# COMMAND ----------

df_fact.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/FactStream/checkpoint")\
    .trigger(once=True)\
    .option("path","abfss://silver@spotifyprojectdlyash.dfs.core.windows.net/FactStream/data")\
    .toTable("spotify_cata.silver.FactStream")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT * FROM spotify_cata.silver.FactStream

# COMMAND ----------

